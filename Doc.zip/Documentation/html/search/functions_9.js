var searchData=
[
  ['joystick_5faxis_5fx',['joystick_axis_x',['../manager_8c.html#a618520d724223e77f86964f501df4ba6',1,'manager.c']]],
  ['joystick_5faxis_5fy',['joystick_axis_y',['../manager_8c.html#a57d9517905c0cd01f8edba92b992e6be',1,'manager.c']]],
  ['joystick_5fbutton_5fmanager',['joystick_button_manager',['../lib__graph_8h.html#a8ac1ba10ecf1696bb6c235bc0f9cc510',1,'joystick_button_manager(animator_t *):&#160;manager.c'],['../manager_8c.html#a84da4eae084b1ddc33ec9e409f9e2eb6',1,'joystick_button_manager(animator_t *self):&#160;manager.c']]],
  ['joystick_5fmanager',['joystick_manager',['../lib__graph_8h.html#a257924c0029727779145a66f1998346a',1,'joystick_manager(animator_t *):&#160;manager.c'],['../manager_8c.html#adcd7683df0b91b92805a9f4ff7d25048',1,'joystick_manager(animator_t *self):&#160;manager.c']]],
  ['joystick_5fmoved',['joystick_moved',['../lib__graph_8h.html#a16ee4b4e46c21e0a11ab495a7439db9d',1,'joystick_moved(animator_t *):&#160;manager.c'],['../manager_8c.html#a455f9302a9b898dc50413a3b43702ca3',1,'joystick_moved(animator_t *self):&#160;manager.c']]],
  ['joystickwapper',['joystickwapper',['../mapping_8c.html#a8e4cd0ee3cbc9876f0a590a5a02aa0d6',1,'mapping.c']]]
];
