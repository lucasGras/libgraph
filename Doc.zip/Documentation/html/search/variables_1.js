var searchData=
[
  ['b',['b',['../structrgb__t.html#ae49f3e2127b20f118ad42e5f38e56ad5',1,'rgb_t']]],
  ['box_5fsprt',['box_sprt',['../structdialog__box__s.html#a46dd084ccb0bcc29b3bbd36baec424d6',1,'dialog_box_s']]],
  ['box_5ftxtr',['box_txtr',['../structdialog__box__s.html#a994d6d35c2cc0165e2dc08987fae8535',1,'dialog_box_s']]],
  ['buble_5fstr',['buble_str',['../structbutton__s.html#a74fa4795b6ee776477661065797b4f73',1,'button_s']]],
  ['button_5fpos',['button_pos',['../structdialog__box__s.html#ac1bbdda85a0a417d5693133272755057',1,'dialog_box_s']]]
];
