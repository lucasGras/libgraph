var searchData=
[
  ['dialog_5fbox_5fs',['dialog_box_s',['../structdialog__box__s.html',1,'']]],
  ['dialog_5fbox_5ft',['dialog_box_t',['../structdialog__box__t.html',1,'']]]
];
