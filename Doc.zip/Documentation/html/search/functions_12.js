var searchData=
[
  ['wait_5fand_5fget_5fseconds',['wait_and_get_seconds',['../lib__graph_8h.html#a42b7dc85dd85dfe8c6c52d53bb22825a',1,'wait_and_get_seconds(float):&#160;timer.c'],['../timer_8c.html#a56a072ba817b3f9ec4f612f5f7c2df5b',1,'wait_and_get_seconds(float timer):&#160;timer.c']]],
  ['wait_5ffor_5fseconds',['wait_for_seconds',['../lib__graph_8h.html#ab96ef764effaa84c17dcd0907f235b32',1,'wait_for_seconds(float):&#160;timer.c'],['../timer_8c.html#ae503d61db492dd091414109ee01506ac',1,'wait_for_seconds(float timer):&#160;timer.c']]]
];
