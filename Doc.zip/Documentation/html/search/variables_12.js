var searchData=
[
  ['window_5fptr',['window_ptr',['../structpnj__component__s.html#ab3fbed8f204bf31f4ebedd57fb923f37',1,'pnj_component_s::window_ptr()'],['../structplayer__s.html#abcb82bf7e661ca41bf2293ce5bf97495',1,'player_s::window_ptr()']]]
];
