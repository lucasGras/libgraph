var searchData=
[
  ['magic_5fdamage',['magic_damage',['../structinventory__item__t.html#aa9497e17efac34c24bdeec0bc29ed9d4',1,'inventory_item_t']]],
  ['mana',['mana',['../structplayer__s.html#a9fe0dcdfa31adde3746ef0c037e54625',1,'player_s']]],
  ['manage_5fevent',['manage_event',['../structanimator__s.html#aee9cd8c8caf0cc098e2bfa08ed1500bf',1,'animator_s']]],
  ['max_5finventory_5fsize',['max_inventory_size',['../structplayer__s.html#a5bad57d92025e17a498ff8159d8a30d3',1,'player_s']]],
  ['max_5frotation_5fspeed',['max_rotation_speed',['../structparticle__system__s.html#ab20bcd6b639b9eb300b61c87ac3d57cc',1,'particle_system_s']]],
  ['max_5fspeed',['max_speed',['../structparticle__system__s.html#ac55569233d82ea5c0c5c33253f1fb0e0',1,'particle_system_s']]],
  ['message',['message',['../structbutton__s.html#ae083f2916c994fc74e4315462fe5b916',1,'button_s']]],
  ['min_5fspeed',['min_speed',['../structparticle__system__s.html#af1a69c93260be82665096b410a2cff26',1,'particle_system_s']]],
  ['move_5frect',['move_rect',['../structanimator__s.html#ac9d6a509683c4a725039ef27583107aa',1,'animator_s']]],
  ['mvt_5fclock',['mvt_clock',['../structparticle__system__s.html#a515ed88e6c6e6de4b20d2d781ebcfd0c',1,'particle_system_s']]]
];
