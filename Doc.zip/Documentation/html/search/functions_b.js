var searchData=
[
  ['new_5fvector2f',['new_vector2f',['../lib__graph_8h.html#add31cb9b209b76dc4bc9f4d78d0c40bb',1,'new_vector2f(float, float):&#160;vector.c'],['../vector_8c.html#ab96c547a89435ba82ea7ab657869c1a7',1,'new_vector2f(float x, float y):&#160;vector.c']]],
  ['new_5fvector2i',['new_vector2i',['../lib__graph_8h.html#a3871c14aa48f2a6000c00e9599477eb1',1,'new_vector2i(int, int):&#160;vector.c'],['../vector_8c.html#a7edd33d39a68d9d38bb548c821e55541',1,'new_vector2i(int x, int y):&#160;vector.c']]]
];
